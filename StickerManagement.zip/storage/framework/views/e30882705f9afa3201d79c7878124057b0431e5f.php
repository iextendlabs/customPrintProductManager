<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
<body>
  <div class="container-scroller">
      <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row ">
              <div class="col-12 grid-margin">
                <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Add Product</h3><br>
                    <?php if(Session::get('success')): ?>
                    <span style="color: #9ae890 !important;"><?php echo e((Session::get('success'))); ?></span>
                    <?php endif; ?>

                    <?php if(Session::get('fail')): ?>
                    <span style="color: #f44336 !important;"><?php echo e((Session::get('fail'))); ?></span>
                    <?php endif; ?>
                    <form action="addProduct" method="post" enctype="multipart/form-data" id="form-product" class="form-horizontal">
                      <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label class="col-sm-2 control-label" for="input-name">Name</label>
                        <div class="col-sm-10">
                          <input type="text" name="name" placeholder="Entry Name" id="input-name" value="<?php echo e(old('name')); ?>" class="form-control" />
                          <span style="color: #f44336 !important;"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-2 control-label" for="input-drive-link">Drive Link</label>
                        <div class="col-sm-10">
                          <input type="text" name="drive_link"  placeholder="Entry Drive Link" id="input-drive-link" value="<?php echo e(old('drive_link')); ?>" class="form-control" />
                          <span style="color: #f44336 !important;"><?php $__errorArgs = ['drive_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-2 control-label" for="input-sku">SKU</label>
                        <div class="col-sm-10">
                          <input type="text" name="sku" placeholder="Entry SKU" id="input-sku" value="<?php echo e(old('sku')); ?>" class="form-control" />
                          <span style="color: #f44336 !important;"><?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                      </div><br>
                      <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="input-daraz">Daraz</label>
                        <div class="col-sm-10">
                          <div class="form-check form-switch form-switch-lg">
                            <h3><input type="checkbox" name="daraz" value="1" id="input-daraz" class="form-check-input"/></h3>
                          </div>
                        </div>
                      </div><br>
                      <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="input-decorguys">Decorguys</label>
                        <div class="col-sm-10">
                          <div class="form-check form-switch form-switch-lg">
                            <h3><input type="checkbox" name="decorguys" value="1" id="input-decorguys" class="form-check-input"/></h3>
                          </div>
                        </div>
                      </div><br>
                      <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="input-carstickers">Carstickers</label>
                        <div class="col-sm-10">
                          <div class="form-check form-switch form-switch-lg">
                            <h3><input type="checkbox" name="carstickers" value="1" id="input-carstickers" class="form-check-input"/></h3>
                          </div>
                        </div>
                      </div><br>
                      <div class="form-group">
                        <label class="col-sm-2 control-label" for="input-image">Image</label>
                        <div class="col-sm-10">
                          <input type="file" name="image" id="input-image" value="<?php echo e(old('image')); ?>" class="form-control" />
                          <span style="color: #f44336 !important;"><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-2 control-label" for="input-artcut-file">ArtCut File</label>
                        <div class="col-sm-10">
                          <input type="file" name="artcut_file" id="input-artcut-file" value="<?php echo e(old('artcut_file')); ?>" class="form-control" />
                          <span style="color: #f44336 !important;"><?php $__errorArgs = ['artcut_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-2 control-label" for="input-other-artcut-file">Other ArtCut File</label>
                        <div class="col-sm-10">
                          <input type="file" name="other_artcut_file" id="input-other-artcut-file" value="<?php echo e(old('other_artcut_file')); ?>" class="form-control" />
                          <span style="color: #f44336 !important;"><?php $__errorArgs = ['other_artcut_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                      </div>
                      <button type="submit" form="form-product" data-toggle="tooltip" title="Save" class="badge badge-outline-success">Save</button>
                      <a href="<?php echo e(url('/')); ?>"><button type="button" data-toggle="tooltip" title="Cancel" class="badge badge-outline-warning">Cancel</button></a>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © iExtendLabs.com 2022</span>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH D:\xampp\htdocs\laravel\StickerManagement\resources\views/productForm.blade.php ENDPATH**/ ?>